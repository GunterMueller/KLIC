/*
 * Author:      Renato Santana, <renato@nce.ufrj.br> in January, 1996.
 *
 * (Obsoleted in tgif-4.1.9 by the TangramII group at land.ufrj.br.)
 *
 * @(#)$Header: /mm2/home/cvs/bc-src/tgif/wb1.c,v 1.1 2004/06/18 23:19:10 william Exp $
 */

#define _INCLUDE_FROM_WB1_C_

#include "tgifdefs.h"

#ifdef _TGIF_WB

#include "wb1.e"

#endif     /* _TGIF_WB */
