/*
 * Author:      Raphael S. de Moraes <raphael@land.ufrj.br> in April, 1999
 *
 * (Obsoleted in tgif-4.1.41 by the TGWB group at land.ufrj.br.)
 *
 * @(#)$Header: /mm2/home/cvs/bc-src/tgif/wb_mcast.c,v 1.2 2008/10/16 21:13:03 william Exp $
 */

#define _INCLUDE_FROM_WB_MCAST_C_

#include "tgifdefs.h"

#include "wb_mcast.e"
